#!/usr/bin/env python3
"""Deterministic final imagery pass. No network, Git, publishing or image generation.

Manifest: {"page.html": {category,label,city,images:[{slot,src,width,height}],placement_hold}}.
Default is dry-run. --apply writes only after all eligible pages validate; --check
fails if output is stale. This pass belongs last in build-service-site.mjs.
"""
import argparse,html,json,re,sys
from pathlib import Path

START='<!-- page-owned-imagery:start -->';END='<!-- page-owned-imagery:end -->'
STYLE='<link rel="stylesheet" href="page-owned-imagery.css">'
CSS='''.poi-gallery{margin:32px auto;padding:clamp(20px,3vw,36px);background:#f4f4f1;color:#17191c;border-top:4px solid #e5a000}.poi-gallery h2,.poi-gallery h3{margin:0 0 16px}.poi-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px}.poi-grid figure{margin:0;background:#fff;border:1px solid #deded8;border-radius:4px;overflow:hidden}.poi-grid img{display:block;width:100%;height:auto;max-height:640px;object-fit:contain}.poi-grid figcaption{padding:14px 16px;color:#17191c;font-weight:700}.poi-notice{color:#50545a;line-height:1.5}.poi-roofing-page .mr-story,.poi-roofing-page .mr-detail-row,.poi-roofing-page .cr-assembly{display:block}@media(max-width:760px){.poi-grid{grid-template-columns:1fr}}\n'''
FIGURE=re.compile(r'<figure\b[^>]*>.*?</figure>',re.S|re.I)
SRC=re.compile(r'<img\b[^>]*\bsrc="([^"]+)"',re.I)
SENSITIVE=set()

def bounded(pattern,replacement,text,allowed):
 result,n=re.subn(pattern,replacement,text,flags=re.S)
 if n not in allowed:raise ValueError(f'Unexpected structure: {pattern}: {n}')
 return result

def block(text,start,end):
 if text.count(start)!=text.count(end) or text.count(start)>1:raise ValueError(f'Unpaired/duplicate {start}')
 return re.search(re.escape(start)+r'.*?'+re.escape(end),text,re.S)

def remove_previous(text):
 for start,end in [(START,END),('<!-- page-owned-concepts:start -->','<!-- page-owned-concepts:end -->')]:
  m=block(text,start,end)
  if m:text=text[:m.start()]+text[m.end():]
 # Initial migration may have the earlier pilot's explicit section rather than markers.
 text=bounded(r'<section class="page-owned-roof-gallery"[^>]*>.*?</section>','',text,{0,1})
 # Remove only this pass's stylesheet; it is reinstated deterministically.
 return text.replace(STYLE+'\n','').replace(STYLE,'')

def render_gallery(entry,images,genuine=()):
 label=entry['label'];city=entry.get('city') or 'Dallas–Fort Worth'
 caption=f'{label} · {city}'
 cards=[]
 for i in sorted(images,key=lambda x:x['slot']):
  esc=lambda v:html.escape(str(v),quote=True)
  subject=i.get('caption_subject',label)
  caption=f'{subject} · {city}'
  alt=f'{subject} concept · {city}'
  cards.append(f'<figure data-representative-generated-illustration="true" data-page-owned-slot="{int(i["slot"]):02}"><img src="{esc(i["src"])}" alt="{esc(alt)}" width="{int(i["width"])}" height="{int(i["height"])}" loading="lazy" decoding="async"><figcaption>{esc(caption)}</figcaption></figure>')
 notice='AI-created design concepts.'
 if entry['category']=='site-legal':notice=''
 if entry['category']=='insurance-claims':notice='AI-created planning concepts.'
 return START+'<section class="poi-gallery container" data-page-owned-imagery="true" aria-labelledby="poi-title"><h2 id="poi-title">'+html.escape(entry.get('gallery_title',label+' planning ideas'))+'</h2>'+('<p class="poi-notice">'+notice+'</p>' if notice else '')+'<div class="poi-grid">'+''.join(cards+list(genuine))+'</div></section>'+END

def keep_genuine(markup):
 genuine=[]
 for f in FIGURE.findall(markup):
  if any(x in f for x in ['data-media-kind="genuine-portfolio-photo"','data-media-kind="portfolio-photo"','data-substantive-scene="portfolio-photo"']):raise ValueError('Unremoved work-photo figure: confirm asset inventory before proceeding')
  elif 'representative-illustration' not in f and 'data-representative-generated-illustration="true"' not in f:raise ValueError('Unclassified figure in replaceable gallery')
 return genuine

def clean_basic_service_art(text):
 # Component illustrations remain until the separate three-card replacement batch.
 return text

def transform_roof(text,entry,hub=False):
 for name in ['roofing-products','metal-roofing','commercial-roofing']:
  if not block(text,f'<!-- {name}:start -->',f'<!-- {name}:end -->'):raise ValueError('Missing roof guide '+name)
 # Retain brand text/links; never put generated generic scenes inside brand cards.
 text=bounded(r'<figure class="rp-photo">.*?</figure>','',text,{0,3})
 text=bounded(r'<p class="rp-fine-print"><strong>About the photos:</strong>.*?</p>','<p class="rp-fine-print"><strong>Material selection:</strong> Confirm supplier availability, the exact model and final color for your estimate. Planning concepts do not depict named manufacturer products, inventory or certification.</p>',text,{0,1})
 text=text.replace('before comparing the packages below.','before comparing the product references below.')
 for role in ['primary','detail']:
  text=bounded(r'<figure class="mr-photo mr-photo--(?:panorama|landscape|portrait) mr-photo--'+role+r'">.*?</figure>','',text,{0,1})
 text=bounded(r'<p class="mr-photo-note">.*?</p>','',text,{0,1})
 text=bounded(r'<div class="cr-reference-photos">.*?</div>','',text,{0,1})
 if hub:
  if re.search(r'<img[^>]*src="(?:https?://|assets/metal-roofing/|assets/commercial-roofing/(?:membrane-work.jpg|epdm-roof.jpg))',text):raise ValueError('Unclassified remaining roofing hub reference')
  return text
 old=block(text,'<!-- roofing-city-illustrations:start -->','<!-- roofing-city-illustrations:end -->')
 gallery=render_gallery(entry,entry['images'])
 if old:text=text[:old.start()]+text[old.end():]
 anchor='<!-- commercial-roofing:end -->';text=text.replace(anchor,anchor+gallery,1)
 if not re.search(r'<body\b[^>]*\bclass=',text):text=text.replace('<body','<body class="poi-roofing-page"',1)
 else:text=re.sub(r'(<body\b[^>]*\bclass=")([^"]*)',lambda m:m[1]+m[2] if 'poi-roofing-page' in m[2].split() else m[1]+m[2]+' poi-roofing-page',text,count=1)
 if re.search(r'<img[^>]*src="(?:https?://|assets/metal-roofing/|assets/commercial-roofing/(?:membrane-work.jpg|epdm-roof.jpg))',text):raise ValueError('Unclassified remaining roof reference image')
 return text

def transform(original,entry,page):
 # Recover genuine gallery figures before clearing previous owned markup.
 prior=block(original,START,END);prior_genuine=keep_genuine(prior.group()) if prior else []
 text=remove_previous(original)
 if page=='roofing.html':text=transform_roof(text,entry,hub=True)
 city=block(text,'<!-- service-city-imagery:start -->','<!-- service-city-imagery:end -->')
 roofing=entry['category']=='roofing' and page.endswith('-roofing.html')
 if roofing:text=transform_roof(text,entry)
 elif city:
  genuine=keep_genuine(city.group())+prior_genuine
  genuine=list(dict.fromkeys(genuine))
  text=text[:city.start()]+'<!-- service-city-imagery:start -->'+render_gallery(entry,entry['images'],genuine)+'<!-- service-city-imagery:end -->'+text[city.end():]
  text=clean_basic_service_art(text)
 else:
  hub=None if page=='index.html' else block(text,'<!-- service-hub-illustrations:start -->','<!-- service-hub-illustrations:end -->')
  if hub:
   if not all(s.startswith('assets/images/illustrations/') for s in SRC.findall(hub.group())):raise ValueError('Unclassified hub image')
   text=text[:hub.start()]+'<!-- service-hub-illustrations:start -->'+render_gallery(entry,entry['images'],prior_genuine)+'<!-- service-hub-illustrations:end -->'+text[hub.end():]
  else:
   # Existing assigned hero/cards stay in place; add only missing mapped images.
   already=set(SRC.findall(text));missing=[i for i in entry['images'] if i['src'] not in already]
   if missing or prior_genuine:
    gallery=render_gallery(entry,missing,prior_genuine)
    anchor='<!-- shared-customer-reviews:start -->' if '<!-- shared-customer-reviews:start -->' in text else '</main>'
    if anchor in text:offset=text.index(anchor)
    else:
     m=re.search(r'<footer\b',text,re.I)
     if not m:raise ValueError('No safe gallery insertion anchor')
     offset=m.start()
    text=text[:offset]+gallery+text[offset:]
 if START in text:
  if '</head>' not in text:raise ValueError('Missing head close')
  text=text.replace('</head>',STYLE+'\n</head>',1)
 # Genuine non-illustrative/non-reference image elements remain intact.
 removed_prefixes=('assets/images/illustrations/','assets/service-guides/')
 if roofing or page=='roofing.html':removed_prefixes+=('assets/metal-roofing/','assets/commercial-roofing/','https://mobileimages.lowes.com/')
 for image in re.findall(r'<img\b[^>]*>',original):
  src=SRC.search(image)
  if src and not src[1].startswith(removed_prefixes) and image not in text:raise ValueError('Genuine or unclassified image changed: '+src[1])
 for i in entry['images']:
  if i['src'] not in SRC.findall(text):raise ValueError('Assigned image absent: '+i['src'])
 if text.count(START)>1:raise ValueError('Duplicate owned gallery')
 return text

# Confirmed work-photo placements are removed; source assets are never modified.
from html.parser import HTMLParser
from urllib.parse import urlsplit,unquote
import posixpath,hashlib

def photo_key(value,file='index.html'):
 value=html.unescape(value).strip()
 if value.startswith('data:'):return None
 u=urlsplit(value)
 if u.netloc and u.netloc not in {'lunageneralcontractors.com','www.lunageneralcontractors.com'}:return None
 path=unquote(u.path)
 if not path:return None
 if path.startswith('/'):return posixpath.normpath(path.lstrip('/'))
 return posixpath.normpath(posixpath.join(posixpath.dirname(file),path))

class PhotoNodes(HTMLParser):
 def __init__(self,text):
  super().__init__(convert_charrefs=False);self.text=text;self.lines=[0];self.nodes=[];self.stack=[]
  self.lines += [m.end() for m in re.finditer('\n',text)];self.feed(text);self.close()
 def pos(self):
  line,col=self.getpos();return self.lines[line-1]+col
 def handle_starttag(self,tag,attrs):
  start=self.pos();raw=self.get_starttag_text();node={'tag':tag,'attrs':dict(attrs),'start':start,'open_end':start+len(raw),'end':None,'parent':self.stack[-1] if self.stack else None}
  self.nodes.append(node)
  if tag in {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}:node['end']=node['open_end']
  else:self.stack.append(node)
 def handle_startendtag(self,tag,attrs):
  self.handle_starttag(tag,attrs)
  if self.stack and self.stack[-1] is self.nodes[-1]:self.stack.pop()['end']=self.nodes[-1]['open_end']
 def handle_endtag(self,tag):
  for i in range(len(self.stack)-1,-1,-1):
   if self.stack[i]['tag']==tag:
    end=self.text.find('>',self.pos())+1
    for n in self.stack[i:]:n['end']=end
    del self.stack[i:];break

def strip_real_photos(text,assets,file):
 edits=[]
 def known(value):return photo_key(value or '',file) in assets
 if file.endswith('.css'):
  for m in re.finditer(r'url\(\s*(["\']?)(.*?)\1\s*\)',text,re.I):
   if known(m[2]):edits.append((m.start(),m.end(),'none','confirmed-photo-css-url',photo_key(m[2],file)))
 else:
  tree=PhotoNodes(text)
  for n in tree.nodes:
   a=n['attrs'];tag=n['tag'];matched=[(k,v) for k,v in a.items() if v and k in {'src','href','xlink:href','poster','data-src','data-image','data-full','data-before','data-after','data-background','content'} and known(v)]
   if a.get('srcset'):
    matched += [('srcset',x.strip().split()[0]) for x in a['srcset'].split(',') if x.strip() and known(x.strip().split()[0])]
   if matched:
    target=n
    if tag in {'img','source','image','video'}:
     chain=[];parent=n['parent']
     while parent:
      chain.append(parent);parent=parent['parent']
     comparisons=[p for p in chain if re.search(r'(?:before[-_]?after|comparison-slider|ba-slider)',p['attrs'].get('class','')+' '+p['attrs'].get('id',''),re.I)]
     gallery_classes={'city-gallery','portfolio-proof','gallery-section','mp-gallery','project-gallery'}
     galleries=[p for p in chain if gallery_classes.intersection(p['attrs'].get('class','').split()) and p['end'] is not None and all(known(src) for src in SRC.findall(text[p['start']:p['end']]))]
     figures=[p for p in chain if p['tag']=='figure'];pictures=[p for p in chain if p['tag']=='picture']
     if galleries:target=galleries[-1]
     elif comparisons:target=comparisons[0]
     elif figures:target=figures[0]
     elif pictures:target=pictures[0]
    elif tag not in {'a','meta'}:
     # Remove exact data/reference attributes rather than an unrelated container.
     raw=text[n['start']:n['open_end']];new=raw
     for k,v in matched:new=re.sub(r'\s+'+re.escape(k)+r'\s*=\s*(["\']).*?\1',lambda m:'' if known(re.search(r'=\s*(["\'])(.*?)\1',m[0],re.S)[2]) else m[0],new,flags=re.S)
     if new!=raw:edits.append((n['start'],n['open_end'],new,'confirmed-photo-attribute',','.join(photo_key(v,file) or '' for k,v in matched)))
     continue
    if target['end'] is None:raise ValueError('Unclosed photo wrapper in '+file)
    edits.append((target['start'],target['end'],'','confirmed-photo-placement',','.join(photo_key(v,file) or '' for k,v in matched)))
  # CSS references inside style attributes and style blocks are handled without deleting layout.
  for m in re.finditer(r'url\(\s*(["\']?)(.*?)\1\s*\)',text,re.I):
   if known(m[2]):edits.append((m.start(),m.end(),'none','confirmed-photo-css-url',photo_key(m[2],file)))
  # Structured social/project metadata must not continue advertising removed photo evidence.
  OMIT=object()
  def clean(value):
   if isinstance(value,str):return OMIT if known(value) else value
   if isinstance(value,list):return [c for v in value if (c:=clean(v)) is not OMIT]
   if isinstance(value,dict):return {k:c for k,v in value.items() if (c:=clean(v)) is not OMIT}
   return value
  for m in re.finditer(r'<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',text,re.S|re.I):
   try:old=json.loads(m[1]);new=clean(old)
   except json.JSONDecodeError:continue
   if old!=new:edits.append((m.start(1),m.end(1),json.dumps(new,separators=(',',':')),'confirmed-photo-structured-metadata',''))
 # Remove stale gallery presentation claims only when this document lost photo placements.
 if edits and not file.endswith('.css'):
  replacements={
   'Open a case study to see the documented challenge, completed scope, materials, date and project photographs.':'Open a case study to see the documented challenge, completed scope, materials and date.',
   'Completed work is supported with project photos, locations and individual case-study pages.':'Explore project locations and individual case-study summaries.',
   'Representative portfolio images are labeled clearly when the original project photographs are not published.':'Project photography is not displayed on this page.',
   'Existing Luna portfolio photographs are identified as Dallas-Fort Worth references, not work in this page’s city.':'',
  }
  for before,after in replacements.items():
   for match in re.finditer(re.escape(before),text):edits.append((match.start(),match.end(),after,'removed-photo-evidence-label',''))
  for match in re.finditer(r'<h[1-6]\b[^>]*>\s*(?:Project Gallery|Project Photos|Before\s*(?:&amp;|and|/|&amp;amp;)\s*After|Galería del proyecto|Antes y después)\s*</h[1-6]>',text,re.I):
   edits.append((match.start(),match.end(),'','empty-photo-gallery-heading',''))
 # Prefer containing removals; reject unrelated overlapping replacements.
 chosen=[]
 for edit in sorted(edits,key=lambda e:(e[0],-(e[1]-e[0]))):
  if chosen and edit[0]<chosen[-1][1]:
   if edit[1]<=chosen[-1][1] and chosen[-1][2]=='':continue
   if edit[:3]==chosen[-1][:3]:continue
   raise ValueError('Overlapping photo-removal edits in '+file)
  chosen.append(edit)
 result=text
 for start,end,new,reason,src in reversed(chosen):result=result[:start]+new+result[end:]
 log=[{'file':file,'start':a,'end':b,'before':text[a:b],'after':new,'reason':why,'asset':src} for a,b,new,why,src in chosen]
 return result,log


def concise_image_text(text,entry,page):
 text=re.sub(r'(src=["\']script\.js)(?:\?[^"\']*)?(["\'])',r'\1?v=20261024-concepts\2',text)
 city=entry.get('city') or 'Dallas–Fort Worth';label=entry['label']
 def short_figure(match):
  figure=match.group();sources=SRC.findall(figure)
  if len(sources)!=1:return figure
  src=sources[0]
  technical=src.startswith('assets/service-guides/') or (src.startswith('assets/commercial-roofing/') and src.endswith('.svg'))
  concept=src.startswith('assets/images/illustrations/')
  if not (technical or concept):return figure
  subject=next((i.get('caption_subject',label) for i in entry.get('images',[]) if i['src']==src),label)
  if technical:
   subject=Path(src).stem.replace('-reference','').replace('-',' ').capitalize()
   subject={'Tpo':'TPO','Pvc':'PVC','Epdm':'EPDM','Gypsum':'Drywall'}.get(subject,subject)
  caption=html.escape(subject+' · '+city)
  figure=re.sub(r'<figcaption\b[^>]*>.*?</figcaption>',lambda m:'<figcaption>'+caption+'</figcaption>',figure,flags=re.S)
  alt=html.escape(subject+(' illustration' if technical else ' concept')+' · '+city,quote=True)
  figure=re.sub(r'(<img\b[^>]*\balt=")[^"]*',lambda m:m[1]+alt,figure,count=1)
  return figure
 text=FIGURE.sub(short_figure,text)
 text=re.sub(r'<p class="sg-note sg-note--generated-media">.*?</p>','<p class="sg-note sg-note--generated-media">Design concepts; brand references are separate.</p>',text,flags=re.S)
 text=text.replace('>Generated planning illustrations</p>','>Design concepts</p>')
 text=re.sub(r'<p>Generated illustrations support[^<]+</p>','',text)
 # Remove old boilerplate only inside image-caption context, never educational body.
 for match in re.finditer(r'<figcaption\b[^>]*>(.*?)</figcaption>',text,re.S):
  visible=html.unescape(re.sub('<[^>]+>',' ',match[1]));visible=' '.join(visible.split())
  if re.search(r'Original category illustration|Model appearance varies|not a (?:Luna |completed )?project|Generated planning illustrations',visible,re.I):
   raise ValueError('Retired image-caption boilerplate in '+page)
 # A removed work photo must not leave its social-image dimensions or actual-job alt.
 text=re.sub(r'<meta\b(?=[^>]*(?:property|name)=["\'](?:og:image(?::[^"\']*)?|twitter:image(?::[^"\']*)?)["\'])[^>]*>','',text,flags=re.I)
 if not entry.get('placement_hold') and entry.get('images'):
  image=entry['images'][0];url='https://lunageneralcontractors.com/'+image['src']
  meta='<meta property="og:image" content="'+html.escape(url,quote=True)+'"><meta property="og:image:width" content="'+str(image['width'])+'"><meta property="og:image:height" content="'+str(image['height'])+'"><meta property="og:image:alt" content="'+html.escape(label+' concept · '+city,quote=True)+'">'
  text=text.replace('</head>',meta+'</head>',1)
 if page=='projects.html':
  text=text.replace('See real Luna roofing, bathroom and kitchen work plus detailed construction case studies across Dallas–Fort Worth.','Explore design concepts and construction case summaries across Dallas–Fort Worth.')
  text=text.replace('See real Luna roofing, bathroom and kitchen work plus detailed construction case studies across Dallas–Fort Worth.','Explore design concepts and construction case summaries across Dallas–Fort Worth.')
  text=text.replace('Every image below shows actual completed work','The gallery shows design concepts')
 return text


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument('--manifest',type=Path);ap.add_argument('--photo-manifest',type=Path);ap.add_argument('--removal-log',type=Path);g=ap.add_mutually_exclusive_group();g.add_argument('--apply',action='store_true');g.add_argument('--check',action='store_true');args=ap.parse_args()
 root=args.root.resolve();manifest=args.manifest or root/'content/page-owned-imagery.json';data=json.loads(manifest.read_text());prepared=[];held=[];removals=[]
 photo_manifest=args.photo_manifest or root/'content/real-job-photo-placements.json'
 photo_data=json.loads(photo_manifest.read_text());assets=set(photo_data if isinstance(photo_data,list) else photo_data['assets'])
 reasons={} if isinstance(photo_data,list) else photo_data.get('reasons',{})
 if not assets or any(not isinstance(x,str) or '..' in Path(x).parts or x.startswith(('http:','https:','data:','/')) for x in assets):raise ValueError('Photo manifest needs confirmed public relative paths')
 for page,entry in sorted(data.items()):
  if not re.fullmatch(r'[a-zA-Z0-9_.-]+\.html',page):raise ValueError('Unsafe page path')
  path=root/page;before=path.read_text();stripped,logs=strip_real_photos(before,assets,page)
  for log in logs:
   if any(reasons.get(a)=='withheld-conflicting-provenance' for a in log['asset'].split(',')):log['reason']='withheld-conflicting-provenance-placement'
  removals.extend(logs)
  if entry.get('placement_hold') or entry['category'] in SENSITIVE:
   held.append(page);after=stripped
  else:
   imgs=entry['images']
   if len(imgs)!=5 or {i['slot'] for i in imgs}!={1,2,3,4,5} or len({i['src'] for i in imgs})!=5:raise ValueError('Invalid five-slot assignment '+page)
   for i in imgs:
    if not i['src'].startswith('assets/images/illustrations/') or '..' in Path(i['src']).parts or not (root/i['src']).is_file():raise ValueError('Unsafe/missing asset '+i['src'])
    if not isinstance(i['width'],int) or not isinstance(i['height'],int) or min(i['width'],i['height'])<1:raise ValueError('Invalid dimensions')
   after=transform(stripped,entry,page)
   if transform(after,entry,page)!=after:raise ValueError('Non-idempotent output '+page)
  after=concise_image_text(after,entry,page)
  repeated,_=strip_real_photos(after,assets,page)
  if not entry.get('placement_hold') and entry['category'] not in SENSITIVE:repeated=transform(repeated,entry,page)
  repeated=concise_image_text(repeated,entry,page)
  if repeated!=after:raise ValueError('Final caption/metadata pass is not idempotent: '+page)
  again,remaining=strip_real_photos(after,assets,page)
  if remaining or again!=after:raise ValueError('Work-photo placement survived removal: '+page)
  if before!=after:prepared.append((path,after))
 # Stylesheets can retain actual photo backgrounds independently of HTML markup.
 for path in sorted(root.rglob('*.css')):
  if any(x.startswith('.') for x in path.relative_to(root).parts):continue
  file=path.relative_to(root).as_posix();before=path.read_text();after,logs=strip_real_photos(before,assets,file);removals.extend(logs)
  if after!=before:prepared.append((path,after))
 css=root/'page-owned-imagery.css';css_stale=not css.exists() or css.read_text()!=CSS
 if args.apply:
  if removals:
   if args.removal_log:logpath=args.removal_log
   else:
    import subprocess
    raw=subprocess.check_output(['git','rev-parse','--git-path','page-owned-photo-removals.json'],cwd=root,text=True).strip()
    logpath=Path(raw) if Path(raw).is_absolute() else root/raw
   previous=json.loads(logpath.read_text()) if logpath.exists() else []
   logpath.parent.mkdir(parents=True,exist_ok=True)
   previous.append({'assets':sorted(assets),'edits':removals,'files':[{'file':str(p.relative_to(root)),'before_document':p.read_text(),'before_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(s.encode()).hexdigest()} for p,s in prepared]})
   logpath.write_text(json.dumps(previous,indent=2))
  for p,s in prepared:p.write_text(s)
  if css_stale:css.write_text(CSS)
 print(json.dumps({'mode':'apply' if args.apply else 'check' if args.check else 'dry-run','changed_files':len(prepared),'concept_placement_held_pages':held,'photo_placements_removed':len(removals),'stylesheet_stale':css_stale}))
 if args.check and (prepared or css_stale):sys.exit(1)

if __name__=='__main__':main()
