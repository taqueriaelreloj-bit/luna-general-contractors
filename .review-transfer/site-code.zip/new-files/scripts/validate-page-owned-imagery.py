"""Validate generated-only page placements without changing any source file."""
import json,re,struct,hashlib,sys
from pathlib import Path
from collections import defaultdict
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parents[1]
class Images(HTMLParser):
 def __init__(self):super().__init__();self.items=[]
 def handle_starttag(self,t,a):
  if t=='img':self.items.append(dict(a))
def dimensions(path):
 b=path.read_bytes()
 if b.startswith(b'\x89PNG\r\n\x1a\n'):return struct.unpack('>II',b[16:24])
 if b[:4]==b'RIFF' and b[8:12]==b'WEBP':
  if b[12:16]==b'VP8 ':return (int.from_bytes(b[26:28],'little')&16383,int.from_bytes(b[28:30],'little')&16383)
  if b[12:16]==b'VP8X':return (1+int.from_bytes(b[24:27],'little'),1+int.from_bytes(b[27:30],'little'))
  if b[12:16]==b'VP8L':
   n=int.from_bytes(b[21:25],'little');return ((n&16383)+1,((n>>14)&16383)+1)
 raise ValueError('Unsupported/malformed assigned image: '+str(path))
def main():
 data=json.loads((ROOT/'content/page-owned-imagery.json').read_text());photo_data=json.loads((ROOT/'content/real-job-photo-placements.json').read_text());photos=photo_data if isinstance(photo_data,list) else photo_data['assets'];owners=defaultdict(set);assigned={};errors=[]
 for page,e in data.items():
  h=(ROOT/page).read_text();parser=Images();parser.feed(h);srcs={i.get('src') for i in parser.items}
  if len(e['images'])!=5 or len({i['src'] for i in e['images']})!=5:errors.append(page+': five unique assignments required')
  for src in srcs:owners[src].add(page)
  for i in e['images']:
   if i['src'] not in srcs:errors.append(page+': missing '+i['src'])
   if i['src'] in assigned:errors.append('Repeated assignment: '+i['src'])
   assigned[i['src']]=page
   p=ROOT/i['src']
   if not p.is_file():errors.append('Missing image file: '+i['src']);continue
   if dimensions(p)!=(i['width'],i['height']):errors.append('Dimension mismatch: '+i['src'])
  for src in photos:
   if src in h:errors.append(page+': removed work-photo reference remains: '+src)
  for i in parser.items:
   if not (i.get('alt') or '').strip():errors.append(page+': empty image alt')
   if (i.get('src') or '').startswith(('http://','https://')):errors.append(page+': external image remains')
 # Public runtime code and CSS must not reinsert archived photos after page load.
 for pattern in ('*.css','*.js'):
  for path in ROOT.rglob(pattern):
   if any(part in ('.git','node_modules') for part in path.relative_to(ROOT).parts):continue
   body=path.read_text(errors='replace')
   for src in photos:
    if src in body:errors.append(str(path.relative_to(ROOT))+': runtime photo reference remains: '+src)
 runtime=(ROOT/'script.js').read_text()
 if 'const pageWorkSlides =' in runtime or 'pageMainForWork.append(workGallery)' in runtime:errors.append('Legacy runtime work-photo injector remains')
 for src,page in assigned.items():
  if owners[src]!={page}:errors.append('Image appears on another canonical page: '+src)
 for src in photos:
  if not (ROOT/src).is_file():errors.append('Original photo was not preserved: '+src)
 if len(data)!=1009 or len(assigned)!=5045:errors.append('Expected 1009 pages and 5045 assigned images')
 if errors:
  print(json.dumps({'errors':errors},indent=2));raise SystemExit(1)
 print(json.dumps({'pages':len(data),'exclusive_assigned_paths':len(assigned),'original_photo_assets_preserved':len(photos),'missing_or_external_images':0,'dimension_checks':'passed'}))
if __name__=='__main__':main()
